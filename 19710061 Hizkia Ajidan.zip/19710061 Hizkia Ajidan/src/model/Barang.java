package model;

public class Barang {
    private int kode_barang;
    private String nama_barang;
    private String tgl_masuk;
    private int harga;

    public Barang(){
    
    }
    
    public Barang(int kode_barang,String nama_barang){
        this.kode_barang = kode_barang;
        this.nama_barang = nama_barang;
    }

    public Barang(int kode_barang, String nama_barang, String tgl_masuk, int harga) {
        this.kode_barang = kode_barang;
        this.nama_barang = nama_barang;
        this.tgl_masuk = tgl_masuk;
        this.harga = harga;
    }

    public void setKode_Barang(int kode_barang) {
        this.kode_barang = kode_barang;
    }

    public void setNama_Barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    public void setTgl_Masuk(String tgl_masuk) {
        this.tgl_masuk = tgl_masuk;
    }

    public void setHarga(int Harga) {
        this.harga = harga;
    }

    public int getKode_barang() {
        return kode_barang;
    }

    public String getNama_Barang() {
        return nama_barang;
    }

    public String getTgl_Masuk() {
        return tgl_masuk;
    }

    public int getHarga() {
        return harga;
    }
}
